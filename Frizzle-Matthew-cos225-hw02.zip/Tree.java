public class Tree{
    public int ID_number;
    public int age;
    public String species_name;
    
    public Tree(int ID, int a, String s){
        ID_number = ID;
        age = a;
        species_name = s;
    }
}